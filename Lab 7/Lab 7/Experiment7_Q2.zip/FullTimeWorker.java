package Experiment7_q2;

class FullTimeWorker extends Worker {
    private String name;
    private double monthlySalary;

    FullTimeWorker(String name, double salary) {
        this.name = name;
        this.monthlySalary = salary;
    }

    @Override
    void computePay() {
        System.out.println(name + "'s Monthly Pay: " + monthlySalary);
    }

    @Override
    void displayInfo() {
        System.out.println("Full-Time Worker: " + name);
    }
}
