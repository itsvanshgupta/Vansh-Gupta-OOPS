package Experiment7_q3;

public class WalletTest {
    public static void main(String[] args) {
        DigitalWallet myWallet = new DigitalWallet();
        myWallet.addFunds(100);
        myWallet.spendFunds(30);
        myWallet.spendFunds(80);
    }
}
