package Experiment7_q3;

class DigitalWallet implements Wallet {
    private double balance = 0;

    @Override
    public void addFunds(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Added: $" + amount + " | New Balance: $" + balance);
        } else {
            System.out.println("Invalid amount.");
        }
    }

    @Override
    public void spendFunds(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Spent: $" + amount + " | New Balance: $" + balance);
        } else {
            System.out.println("Insufficient balance or invalid amount.");
        }
    }
}
